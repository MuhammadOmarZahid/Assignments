 
import random  
import datetime
 
ips = ["192.168.1.50", "10.0.0.15", "185.220.101.5", "172.16.0.5", "192.168.1.22"] 
statuses = ["login_success", "login_failed", "login_failed", "login_failed"] 
users = ["user_root", "user_admin", "user_abdullah", "guest"]  

with open("big_auth.log", "w") as f: 
	base_time = datetime.datetime.now() 
	for i in range(10000):  
		ip = random.choice(ips) 
		if i % 5 == 0: 
 			ip = "185.220.101.5" 
		elif i % 7 == 0: 
			ip = "10.0.0.15" 
		
		status = random.choice(statuses) if ip not in ["185.220.101.5", "10.0.0.15"] else "login_failed"  
		user = random.choice(users) 
		timestamp = base_time + datetime.timedelta(seconds=i) 
		f.write(f"{timestamp.strftime('%Y-%m-%d %H:%M:%S')} IP {ip} {status} {user}\n") 
print("Successfully generated 10,000 security log entries in big_auth.log!") 
