from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col

# Initialize Spark on a single line to prevent backslash errors
spark = SparkSession.builder.appName("DarkPulse-LogAnalyzer").getOrCreate()

# 1. Ingest massive log file from HDFS
raw_logs = spark.read.text("hdfs://localhost:9000/user/abdullah/logs/big_auth.log")

# 2. Filter failed attempts
failed_attempts = raw_logs.filter(raw_logs.value.contains("login_failed"))

# 3. Extract IP addresses
structured_logs = failed_attempts.withColumn("IP_Address", split(col("value"), " ").getItem(3))

# 4. Group and aggregate total attacks
brute_force_summary = structured_logs.groupBy("IP_Address").count()

# 5. Isolate true malicious threats (IPs with more than 100 failed attempts)
critical_threats = brute_force_summary.filter(col("count") > 100).sort(col("count").desc())

print("\n" + "="*60 + "\n [ALERT] DARKPULSE BIG DATA ENGINE: PRODUCTION THREAT REPORT \n" + "="*60)
critical_threats.show()

# 6. Export the security threats to HDFS as a clean CSV directory
critical_threats.write.mode("overwrite").csv("hdfs://localhost:9000/user/abdullah/reports/threat_alerts")
print("Threat report exported successfully to HDFS storage.")

spark.stop()
